create view datos
            (cod_fac, nom_fac, cod_esc, nom_esc, cod_carr, nom_carr, creditos, codigo, orden, matricula, folio, obser,
             centro, modalidad, primera, cedula, nombres, apellidos, fech_nacim, fono_est, domicilio_est, provincia,
             canton, genero, fotografia, email, colegio, canton_coleg, especialidad, periodo, fecha_periodo, fecha,
             cod_asig, nom_asig, paralelo, grupo_comun, mat_arrastre, estado, nota)
as
SELECT facultad.cod_fac,
       facultad.nom_fac,
       escuela.cod_esc,
       escuela.nom_esc,
       carrera.cod_carr,
       carrera.nom_carr,
       carrera.tot_cred_aprob_carr                        AS creditos,
       detalles_matricula.cod_matricula                   AS codigo,
       matricula.orden_matricula                          AS orden,
       detalles_matricula.num_matricula                   AS matricula,
       detalles_matricula.num_folio                       AS folio,
       detalles_matricula.doc_faltantes                   AS obser,
       detalles_matricula.centro,
       detalles_matricula.modalidad,
       carrera_estudiantes.fech_primera_matr              AS primera,
       estudiantes.ced_est                                AS cedula,
       estudiantes.nom_est                                AS nombres,
       estudiantes.apell_est                              AS apellidos,
       estudiantes.fech_nacim,
       estudiantes.fono_est,
       estudiantes.domicilio_est,
       estudiantes.provincia,
       estudiantes.canton,
       estudiantes.genero,
       estudiantes.fotografia,
       estudiantes.email,
       colegio.nom_coleg                                  AS colegio,
       colegio.canton_coleg,
       especialidades.nombre_especialidad                 AS especialidad,
       periodo_lectivo.cod_periodo                        AS periodo,
       periodo_lectivo.fecha_periodo,
       periodo_lectivo.fecha_ini_mat_ordi                 AS fecha,
       creditos_asignaturas_estudiantes.cod_asig,
       asignaturas.nom_asig,
       creditos_asignaturas_estudiantes.paralelo,
       creditos_asignaturas_estudiantes.grupo_comun,
       matricula.mat_arrastre,
       creditos_asignaturas_estudiantes.estado_asignatura AS estado,
       creditos_asignaturas_estudiantes.nota_final_mat    AS nota
FROM detalles_matricula
         JOIN (estudiantes
    JOIN (carrera_estudiantes
        JOIN (carrera
            JOIN (escuela
                JOIN facultad ON facultad.cod_fac = escuela.cod_fac) ON escuela.cod_esc = carrera.cod_esc) ON carrera.cod_carr = carrera_estudiantes.cod_carr) ON carrera_estudiantes.ced_est::text = estudiantes.ced_est::text)
              ON estudiantes.ced_est::text = detalles_matricula.ced_est::text
         JOIN colegio ON estudiantes.cod_coleg = colegio.cod_coleg
         JOIN especialidades ON estudiantes.cod_especialidad = especialidades.cod_especialidad
         JOIN periodo_lectivo ON periodo_lectivo.cod_periodo::text = detalles_matricula.cod_periodo::text
         JOIN (creditos_asignaturas_estudiantes
    JOIN (creditos_asignaturas
        JOIN asignaturas ON asignaturas.cod_asig::text = creditos_asignaturas.cod_asig::text) ON
            creditos_asignaturas.cod_asig_oculto = creditos_asignaturas_estudiantes.cod_asig)
              ON detalles_matricula.cod_periodo::text = creditos_asignaturas_estudiantes.periodo_lectivo::text AND
                 detalles_matricula.ced_est::text = creditos_asignaturas_estudiantes.ced_est::text AND
                 detalles_matricula.cod_carr = carrera.cod_carr
         JOIN matricula ON matricula.cod_matricula = detalles_matricula.cod_matricula AND
                           creditos_asignaturas_estudiantes.cod_asig = matricula.cod_asig
ORDER BY periodo_lectivo.fecha_ini_mat_ordi;

alter table datos
    owner to academico;

